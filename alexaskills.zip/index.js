const Alexa = require('ask-sdk-core');
const request = require('request');
const cheerio = require('cheerio');
let eventsMonths = new Array();
let eventsNames = new Array();
let eventsDates = new Array();
let eventsAddress = new Array();
let saySomething = async function(attributes){
   const today = new Date();
   const month = today.getMonth();
   const year = today.getDate();
  return new Promise(function(resolve) {
  let speakHall = null;
request('https://www.bmcc.cuny.edu/events/', (error, response,html)=>{

  if(!error && response.statusCode == 200){
    const $ = cheerio.load(html);
    $('.tribe-events-list-separator-month').each((i,el)=>{
      const item = $(el).text().replace(/\s\s+/g, '');
      eventsMonths.push(item);
    });
    $('.tribe-event-url').each((i,el)=>{
      const item = $(el).text().replace(/\s\s+/g, '').replace('&','and');
      eventsNames.push(item);
    });
    $('.tribe-event-date-start').each((i,el)=>{
      const item = $(el).text().replace(/\s\s+/g, '');
      eventsDates.push(item);
    });
    $('.tribe-street-address').each((i,el)=>{
      const item = $(el).text().replace(/\s\s+/g, '');
      eventsAddress.push(item);
    });
   if(eventsAddress[attributes] == "199 Chambers Street"){
      speakHall = "main building ";
    }else if(eventsAddress[attributes] == "245 Greenwich Street"){
      speakHall = "fiterman building ";
    }else if(eventsAddress[attributes] == "70 Murray Street"){
      speakHall = "murray building ";
    }
    resolve("There is an event, " + eventsNames[attributes] + " at " + eventsDates[attributes] + ', ' + " in the " + speakHall + "Located at " + eventsAddress[attributes]);
  }
});
});
};
const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';

  },

  handle(handlerInput) {
    // Our skill will receive a LaunchRequest when the user invokes the skill
    // with the  invocation name, but does not provide any utterance
    // mapping to an intent.
    // For Example, "Open bmcc talk"
    const speakOutput = "hello, welcome to bmcc talk, I am able to tell you upcoming events and departments locations. What would you like to know?";

    // The response builder contains is an object that handles generating the
    // JSON response that your skill returns.
    return handlerInput.responseBuilder
      .speak(speakOutput).reprompt("Would you like to know the next event?") // The text passed to speak, is what Alexa will say.
      .getResponse();
  },
};
const EventsHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'eventsIntent';
  },
  async handle(handlerInput) {
    const attributes = handlerInput.attributesManager.getSessionAttributes();
    const random = handlerInput.requestEnvelope.request.intent.slots.eventType.value;
    // This is text that Alexa will speak back
    // when the user says, "Ask code academy to say hello"
    if(!attributes.counter && attributes.counter !== 0){
      attributes.counter = 0;
    }else{
      attributes.counter = attributes.counter + 1;
    }
    const speakOutput = await saySomething(attributes.counter);
    // The response builder contains is an object that handles generating the
    // JSON response that your skill returns.
    handlerInput.attributesManager.setSessionAttributes(attributes);
    return handlerInput.responseBuilder
      .speak(await speakOutput).withShouldEndSession(false) // The text passed to speak, is what Alexa will say.
      .getResponse();
  },
};
const ThanksHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'thankIntent';
  },
  handle(handlerInput) {
    // This is text that Alexa will speak back
    // when the user says, "Ask code academy to say hello"
    const speakOutput = "Your welcome, is there anything else i could help you with";
    // The response builder contains is an object that handles generating the
    // JSON response that your skill returns.
    return handlerInput.responseBuilder
      .speak(speakOutput) // The text passed to speak, is what Alexa will say.
      .getResponse();
  },
};

const HelpHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const speakOutput = "You can say hello to me!";

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const CancelAndStopHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const speakOutput = 'it was a pleasure helping you, GoodBye!';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);
    console.log(error.trace);

    return handlerInput.responseBuilder
      .speak('Sorry, I can\'t understand the command. Please say again.')
      .getResponse();
  },
};

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchRequestHandler,
    EventsHandler,
    HelpHandler,
    CancelAndStopHandler,
    SessionEndedRequestHandler,
    ThanksHandler
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();
